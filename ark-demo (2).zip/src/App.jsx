import { useState } from "react";

export default function App() {
  const [status, setStatus] = useState("Online");
  const [players, setPlayers] = useState(5);

  const restartServer = () => {
    alert("🚀 السيرفر يعاد تشغيله (تجريبي)!");
    setStatus("Restarting...");
    setTimeout(() => setStatus("Online"), 3000);
  };

  const stopServer = () => {
    alert("🛑 السيرفر توقف (تجريبي)!");
    setStatus("Offline");
  };

  const broadcastMsg = () => {
    alert("📢 تم إرسال رسالة عامة (تجريبي)!");
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center">
      <h1 className="text-4xl font-bold mb-6">ARK Demo Panel</h1>

      <div className="bg-gray-800 rounded-2xl p-6 shadow-xl w-80 text-center">
        <h2 className="text-xl mb-2">Server Status</h2>
        <p
          className={`text-lg font-semibold mb-4 ${
            status === "Online" ? "text-green-400" : "text-red-400"
          }`}
        >
          {status}
        </p>
        <p className="mb-4">Players Online: {players}</p>

        <div className="flex flex-col gap-3">
          <button
            onClick={restartServer}
            className="bg-blue-600 hover:bg-blue-700 py-2 rounded-lg"
          >
            Restart
          </button>
          <button
            onClick={stopServer}
            className="bg-red-600 hover:bg-red-700 py-2 rounded-lg"
          >
            Stop
          </button>
          <button
            onClick={broadcastMsg}
            className="bg-green-600 hover:bg-green-700 py-2 rounded-lg"
          >
            Broadcast
          </button>
        </div>
      </div>
    </div>
  );
}